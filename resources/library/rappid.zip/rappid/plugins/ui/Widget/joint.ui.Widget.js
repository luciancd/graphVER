/*! Rappid v2.2.0 - HTML5 Diagramming Framework

Copyright (c) 2015 client IO

 2017-10-23 


This Source Code Form is subject to the terms of the Rappid License
, v. 2.0. If a copy of the Rappid License was not distributed with this
file, You can obtain one at http://jointjs.com/license/rappid_v2.txt
 or from the Rappid archive as was distributed by client IO. See the LICENSE file.*/


(function(joint, $) {

    joint.ui.Widget = joint.mvc.View.extend({

        className: 'widget',
        /** @type {Array.<string>} List of mandatory references, widget cannot be created if any of the reference from list
         * is not defined in options */
        references: [],

        constructor: function(options, refs) {

            this.availableReferences = refs || {};
            joint.mvc.View.prototype.constructor.call(this, options);
        },
        /**
         * @private
         * Apply attributes data onto widget elements.
         * @param {Object.<string, Object>} attrs
         * @returns {jQuery}
         */
        updateAttrs: function(attrs) {

            joint.util.setAttributesBySelector(this.$el, attrs);
        },

        /**
         * @protected
         * Override in specific widget.
         */
        bindEvents: function() {

        },

        /**
         * @private
         */
        validateReferences: function() {
            var refs = this.references || [];
            var ret = [];

            refs.forEach(function(ref) {

                if (this.availableReferences[ref] === undefined) {
                    ret.push(ref);
                }

            }, this);

            return ret;
        },

        /**
         * @protected
         * @param {string} name
         * @returns {*}
         */
        getReference: function(name) {
            return this.availableReferences[name];
        },

        /**
         * @protected
         * @returns {Array.<*>}
         */
        getReferences: function() {
            return this.availableReferences;
        }

    }, {
        /**
         * @param {Object} opt
         * @param {Object?} refs references
         * @returns {joint.ui.Widget}
         */
        create: function(opt, refs) {

            var type = joint.util.camelCase(joint.util.isString(opt) ? opt : opt.type);

            if (!joint.util.isFunction(joint.ui.widgets[type])) {
                throw new Error('Widget: unable to find widget: "' + type + '"');
            }

            var widget = new joint.ui.widgets[type](opt, refs);

            var invalidRefs = widget.validateReferences(refs);
            if (invalidRefs.length > 0) {
                throw new Error('Widget: "' + type + '" missing dependency: ' + invalidRefs.join(', '));
            }

            widget.render();
            widget.updateAttrs(opt.attrs);
            widget.bindEvents();
            widget.$el.attr('data-type', type);

            if (opt.name) {
                widget.$el.attr('data-name', opt.name);
            }

            return widget;
        }
    });

    joint.ui.widgets = {

        checkbox: joint.ui.Widget.extend({

            tagName: 'label',
            events: {
                'change .input': 'onChange',
                'mousedown': 'pointerdown',
                'touchstart': 'pointerdown',
                'mouseup': 'pointerup',
                'touchend': 'pointerup'
            },

            init: function() {
                joint.util.bindAll(this, 'pointerup');
            },

            render: function() {

                var opt = this.options;

                var $label = $('<span/>').text(opt.label || '');
                this.$input = $('<input/>', { type: 'checkbox', 'class': 'input' }).prop('checked', !!opt.value);
                this.$span = $('<span/>');

                this.$el.append([$label, this.$input, this.$span]);

                return this;
            },

            onChange: function(evt) {
                this.trigger('change', !!evt.target.checked, evt);
            },

            pointerdown: function(evt) {
                evt = joint.util.normalizeEvent(evt);
                this.$el.addClass('is-in-action');
                this.trigger('pointerdown', evt);
                $(document).on('mouseup.checkbox touchend.checkbox', this.pointerup);
            },

            pointerup: function(evt) {
                evt = joint.util.normalizeEvent(evt);
                $(document).off('mouseup.checkbox touchend.checkbox');
                this.trigger('pointerdown', evt);
                this.$el.removeClass('is-in-action');
            }
        }),

        toggle: joint.ui.Widget.extend({

            tagName: 'label',
            events: {
                'change input.toggle': 'onChange',
                'mousedown': 'pointerdown',
                'touchstart': 'pointerdown',
                'mouseup': 'pointerup',
                'touchend': 'pointerup'
            },

            init: function() {
                joint.util.bindAll(this, 'pointerup');
            },

            render: function() {

                var opt = this.options;

                var $label = $('<span/>').text(opt.label || '');
                var $button = $('<span><i/></span>');
                var $input = $('<input/>', { type: 'checkbox', class: 'toggle' }).prop('checked', !!opt.value);
                var $wrapper = $('<div/>').addClass(opt.type);

                this.$el.append([$label, $wrapper.append($input, $button)]);

                return this;
            },

            onChange: function(evt) {
                this.trigger('change', !!evt.target.checked, evt);
            },

            pointerdown: function(evt) {
                evt = joint.util.normalizeEvent(evt);
                this.$el.addClass('is-in-action');
                this.trigger('pointerdown', evt);
                $(document).on('mouseup.toggle touchend.toggle', this.pointerup);
            },

            pointerup: function(evt) {
                evt = joint.util.normalizeEvent(evt);
                $(document).off('mouseup.toggle touchend.toggle');
                this.$el.removeClass('is-in-action');
                this.trigger('pointerup', evt);
            }
        }),

        separator: joint.ui.Widget.extend({

            render: function() {

                if (this.options.width) {
                    this.$el.css({ width: this.options.width });
                }

                return this;
            }
        }),

        label: joint.ui.Widget.extend({

            tagName: 'label',

            render: function() {

                this.$el.text(this.options.text);

                return this;
            }
        }),

        range: joint.ui.Widget.extend({

            events: {
                'change .input': 'onChange',
                'input .input': 'onChange'
            },

            render: function() {

                var opt = this.options;
                var $units;

                this.$output = $('<output/>').text(opt.value);
                $units = $('<span/>').addClass('units').text(opt.unit);
                this.$input = $('<input/>', {
                    type: 'range',
                    name: opt.type,
                    min: opt.min,
                    max: opt.max,
                    step: opt.step,
                    'class': 'input'
                }).val(opt.value);

                this.$el.append([this.$input, this.$output, $units]);

                return this;
            },

            onChange: function(evt) {

                var value = parseInt(this.$input.val(), 10);
                if (value === this.currentValue) {
                    return ;
                }

                this.currentValue = value;
                this.$output.text(value);
                this.trigger('change', value, evt);
            },

            setValue: function(value) {
                this.$input.val(value);
                this.$input.trigger('change');
            }
        }),

        selectBox: joint.ui.Widget.extend({

            render: function() {

                var selectBoxOptions = joint.util.omit(this.options, 'type', 'group', 'index');

                this.selectBox = new joint.ui.SelectBox(selectBoxOptions);
                this.selectBox.render().$el.appendTo(this.el);

                return this;
            },

            bindEvents: function() {
                this.selectBox.on('all', this.trigger, this);
            }
        }),

        button: joint.ui.Widget.extend({

            events: {
                'mousedown': 'pointerdown',
                'touchstart': 'pointerdown',
                'click': 'pointerclick',
                'touchend': 'pointerclick'
            },
            tagName: 'button',

            render: function() {

                var opt = this.options;

                this.$el.text(opt.text);

                return this;
            },

            pointerclick: function(evt) {
                evt = joint.util.normalizeEvent(evt);
                this.trigger('pointerclick', evt);
            },

            pointerdown: function(evt) {
                evt = joint.util.normalizeEvent(evt);
                this.trigger('pointerdown', evt);
            }
        }),

        inputText: joint.ui.Widget.extend({

            events: {
                'mousedown': 'pointerdown',
                'touchstart': 'pointerdown',
                'mouseup': 'pointerup',
                'touchend': 'pointerup',
                'click': 'pointerclick',
                'focusin' : 'pointerfocusin',
                'focusout' : 'pointerfocusout'
            },
            tagName: 'div',

            render: function() {

                var opt = this.options;

                this.$label = $('<label/>').text(opt.label);
                this.$input = $('<div/>').addClass('input-wrapper').append( $('<input/>', {
                    type: 'text',
                    'class': 'input'
                }).val(opt.value) );

                this.$el.append([this.$label, this.$input]);

                return this;
            },

            pointerclick: function(evt) {
                evt = joint.util.normalizeEvent(evt);
                this.trigger('pointerclick', evt);
            },

            pointerdown: function(evt) {
                evt = joint.util.normalizeEvent(evt);
                this.trigger('pointerdown', evt);
            },

            pointerup: function(evt) {
                evt = joint.util.normalizeEvent(evt);
                this.trigger('pointerup', evt);
            },

            pointerfocusin: function(evt) {
                evt = joint.util.normalizeEvent(evt);
                this.$el.addClass('is-focused');
                this.trigger('pointerfocusin', evt);
            },

            pointerfocusout: function(evt) {
                evt = joint.util.normalizeEvent(evt);
                this.$el.removeClass('is-focused');
                this.trigger('pointerfocusout', evt);
            }
        }),

        inputNumber: joint.ui.Widget.extend({

            events: {
                'mousedown': 'pointerdown',
                'touchstart': 'pointerdown',
                'mouseup': 'pointerup',
                'touchend': 'pointerup',
                'click': 'pointerclick',
                'focusin' : 'pointerfocusin',
                'focusout' : 'pointerfocusout'
            },
            tagName: 'div',

            render: function() {

                var opt = this.options;

                this.$label = $('<label/>').text(opt.label);
                this.$input = $('<div/>').addClass('input-wrapper').append( $('<input/>', {
                    type: 'number',
                    'class': 'number',
                    max: opt.max,
                    min: opt.min
                }).val(opt.value) );

                this.$el.append([this.$label, this.$input]);

                return this;
            },

            pointerclick: function(evt) {
                evt = joint.util.normalizeEvent(evt);
                this.trigger('pointerclick', evt);
            },

            pointerdown: function(evt) {
                evt = joint.util.normalizeEvent(evt);
                this.trigger('pointerdown', evt);
            },

            pointerup: function(evt) {
                evt = joint.util.normalizeEvent(evt);
                this.trigger('pointerup', evt);
            },

            pointerfocusin: function(evt) {
                evt = joint.util.normalizeEvent(evt);
                this.$el.addClass('is-focused');
                this.trigger('pointerfocusin', evt);
            },

            pointerfocusout: function(evt) {
                evt = joint.util.normalizeEvent(evt);
                this.$el.removeClass('is-focused');
                this.trigger('pointerfocusout', evt);
            }
        }),

        textarea: joint.ui.Widget.extend({

            events: {
                'mousedown': 'pointerdown',
                'touchstart': 'pointerdown',
                'mouseup': 'pointerup',
                'touchend': 'pointerup',
                'click': 'pointerclick',
                'focusin' : 'pointerfocusin',
                'focusout' : 'pointerfocusout'
            },
            tagName: 'div',

            render: function() {

                var opt = this.options;

                this.$label = $('<label/>').text(opt.label);
                this.$input = $('<div/>').addClass('input-wrapper').append( $('<textarea/>', {
                    'class': 'textarea'
                }).text(opt.value) );

                this.$el.append([this.$label, this.$input]);

                return this;
            },

            pointerclick: function(evt) {
                evt = joint.util.normalizeEvent(evt);
                this.trigger('pointerclick', evt);
            },

            pointerdown: function(evt) {
                evt = joint.util.normalizeEvent(evt);
                this.trigger('pointerdown', evt);
            },

            pointerup: function(evt) {
                evt = joint.util.normalizeEvent(evt);
                this.trigger('pointerup', evt);
            },

            pointerfocusin: function(evt) {
                evt = joint.util.normalizeEvent(evt);
                this.$el.addClass('is-focused');
                this.trigger('pointerfocusin', evt);
            },

            pointerfocusout: function(evt) {
                evt = joint.util.normalizeEvent(evt);
                this.$el.removeClass('is-focused');
                this.trigger('pointerfocusout', evt);
            }
        }),

        selectButtonGroup: joint.ui.Widget.extend({

            render: function() {

                var selectButtonGroupOptions = joint.util.omit(this.options, 'type', 'group', 'index');

                this.selectButtonGroup = new joint.ui.SelectButtonGroup(selectButtonGroupOptions);
                this.selectButtonGroup.render().$el.appendTo(this.el);

                return this;
            },

            bindEvents: function() {
                this.selectButtonGroup.on('all', this.trigger, this);
            }
        })
    };

    joint.ui.widgets.zoomIn = joint.ui.widgets.button.extend({

        references: ['paperScroller'],
        options: {
            min: 0.2,
            max: 5,
            step: 0.2
        },

        pointerdown: function(evt) {

            var opt = this.options;

            this.getReferences().paperScroller.zoom(opt.step, { max: opt.max, grid: opt.step });
            joint.ui.widgets.button.prototype.pointerdown.call(this, evt);
        }
    });

    joint.ui.widgets.zoomOut = joint.ui.widgets.button.extend({

        references: ['paperScroller'],
        options: {
            min: 0.2,
            max: 5,
            step: 0.2
        },

        pointerdown: function(evt) {

            var opt = this.options;

            this.getReferences().paperScroller.zoom(-opt.step, { min: opt.min, grid: opt.step });
            joint.ui.widgets.button.prototype.pointerdown.call(this, evt);
        }
    });

    joint.ui.widgets.zoomToFit = joint.ui.widgets.button.extend({

        references: ['paperScroller'],
        options: {
            min: 0.2,
            max: 5,
            step: 0.2
        },

        pointerdown: function(evt) {

            var opt = this.options;

            this.getReferences().paperScroller.zoomToFit({
                padding: 20,
                scaleGrid: opt.step,
                minScale: opt.min,
                maxScale: opt.max
            });
            joint.ui.widgets.button.prototype.pointerdown.call(this, evt);
        }
    });

    joint.ui.widgets.zoomSlider = joint.ui.widgets.range.extend({

        references: ['paperScroller'],
        options: {
            min: 20,
            max: 500,
            step: 20,
            value: 100,
            unit: ' %'
        },

        bindEvents: function() {

            this.on('change', function(value) {
                this.getReferences().paperScroller.zoom(value / 100, { absolute: true, grid: this.options.step / 100 });
            }, this);

            this.getReferences().paperScroller.options.paper.on('scale', function(value) {
                this.setValue(Math.floor(value * 100));
            }, this);
        }
    });

    joint.ui.widgets.undo = joint.ui.widgets.button.extend({

        references: ['commandManager'],

        pointerclick: function() {
            this.getReferences().commandManager.undo();
        }
    });

    joint.ui.widgets.redo = joint.ui.widgets.button.extend({

        references: ['commandManager'],

        pointerclick: function() {
            this.getReferences().commandManager.redo();
        }
    });

    joint.ui.widgets.fullscreen = joint.ui.widgets.button.extend({

        onRender: function() {
            var target = this.target = $(this.options.target)[0];
            if (target && !$.contains(window.top.document, target)) {
                // The fullscreen feature is available only if the target is not displayed within an iframe.
                this.$el.hide();
            }
        },

        pointerclick: function() {
            joint.util.toggleFullScreen(this.target);
        }
    });

}(joint, $));
