/*! Rappid v2.2.0 - HTML5 Diagramming Framework

Copyright (c) 2015 client IO

 2017-10-23 


This Source Code Form is subject to the terms of the Rappid License
, v. 2.0. If a copy of the Rappid License was not distributed with this
file, You can obtain one at http://jointjs.com/license/rappid_v2.txt
 or from the Rappid archive as was distributed by client IO. See the LICENSE file.*/


var $paper = $('#paper');
var graph = new joint.dia.Graph;

new joint.dia.Paper({
    el: $paper,
    width: 1000,
    height: 800,
    gridSize: 1,
    model: graph,
    interactive: false
});

var d = 'M 7.39 4.6 L 67 -10 C 138.92 -20.3 137.03 11 121.36 48.7 C 144.74 79.75 135.09 114.5 76.74 106.2 L 6.5 90 Z';

var p = new joint.shapes.basic.Path({
    position: { x: 100, y: 100 },
    size: { width: 200, height: 200 },
    attrs: { path: { d: d, fill: '#e5e5e5', stroke: '#23272d', strokeWidth: 2 }}
});

graph.addCell(p);

new joint.ui.PathEditor({
    pathElement: document.querySelector('path')
});
