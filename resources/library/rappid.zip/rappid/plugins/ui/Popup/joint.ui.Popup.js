/*! Rappid v2.2.0 - HTML5 Diagramming Framework

Copyright (c) 2015 client IO

 2017-10-23 


This Source Code Form is subject to the terms of the Rappid License
, v. 2.0. If a copy of the Rappid License was not distributed with this
file, You can obtain one at http://jointjs.com/license/rappid_v2.txt
 or from the Rappid archive as was distributed by client IO. See the LICENSE file.*/


// ui.Popup is like ui.ContextToolbar except that it can contain any HTML.
// This is useful for displaying a contextual widget that contains forms or other
// HTML. Popups also have an arrow pointing up.

// @import ui.ContextToolbar

joint.ui.Popup = joint.ui.ContextToolbar.extend({

    className: 'popup',

    eventNamespace: 'popup',

    events: {},

    renderContent: function() {

        var content = joint.util.isFunction(this.options.content) ? this.options.content(this.el) : this.options.content;
        if (content) {
            this.$el.html(content);
        }
    }
});
