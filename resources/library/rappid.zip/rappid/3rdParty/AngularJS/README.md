ANGULAR RAPPID
==============

The demo shows how to integrate Rappid/JointJS with AngularJS.

Install
=======

bower install

Running the app
===============

open index.html

If your browser doesn't allow XHR calls over the file:// protocol you can alternatively run app using
a web server.

http-server
open localhost:8080

